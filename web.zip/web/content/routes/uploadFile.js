'use strict';
var express = require('express');
var router = express.Router();
var sp_commonjs = require('@pnp/sp-commonjs');
var stream_1 = require('stream');
var multer_1 = require('multer');
var fs_1 = require("fs");

const UPLOAD_PATH = 'uploads';
const upload = multer_1({ dest: `${UPLOAD_PATH}/` });

router.post('/', upload.single('file') , (req, res) => {
    if (!req.file) {
        res.send({
            status: false,
            message: 'No file uploaded'
        });
    }
    else {
        console.log(req.body);
        if (req.body.path) {
            const data = fs_1.readFileSync(req.file.path);
            sp_commonjs.sp.web.getFolderByServerRelativeUrl(req.body.path).files.add(req.file.originalname, data, true).then(() => {
                fs_1.unlinkSync(req.file.path);
                return res.json({ status: true });
            }).catch((err) => {
                return res.json({ status: false, message: err.message });
            });
        } else {
            res.send({
                status: false,
                message: 'No path found'
            });
        }
    }
});

module.exports = router;
